#include <iostream>
#include <vector>
using namespace std;

int main()
{
    int a;
    vector<int> list = {a};
    cout << "정수를 입력하시오";
    for (int i = 0; i < 10; i++)

        cin >> a;

    return 0;
}
