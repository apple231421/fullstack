#include <iostream>
#include <string>
using namespace std;

class student
{
private:
    

public:
   

};

int main()
{
    

    return 0;
}
