#include <iostream>
#include <string>
using namespace std;

class animal
{
private:
public:
  
};

int main()
{

    return 0;
}
